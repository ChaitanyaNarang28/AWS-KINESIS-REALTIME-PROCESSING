const AWS = require('aws-sdk');
AWS.config.update({
    region: 'us-east-1'
});
const kinesis = new AWS.Kinesis();

async function streamToKinesis(payload) {
    try {
        const params = {
            Data: JSON.stringify(payload),
            // Using 'productid' (lowercase) instead of 'productId'
            PartitionKey: payload.productid.toString(),
            StreamName: 'cc-data-stream'
        };

        const response = await kinesis.putRecord(params).promise();
        console.log('Kinesis Response:', response);
    } catch (err) {
        console.error('Kinesis error:', err);
        throw new Error('Error sending data to Kinesis');
    }
}

exports.handler = async (event) => {
    try {
        console.log('Event received:', JSON.stringify(event));
        
        const body = JSON.parse(event.body);
        // Passing 'productid' in the payload
        await streamToKinesis(body);

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Data successfully sent to Kinesis.'
            })
        };
    } catch (error) {
        console.error('Handler error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error', error: error.message })
        };
    }
};
