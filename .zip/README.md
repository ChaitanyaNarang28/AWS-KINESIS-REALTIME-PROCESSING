# AWS_Kinesis_demo
Code for AWS Kinesis demo [video](https://www.youtube.com/watch?v=McxSsTmbp00)


## Arch Diagram
![Arch Diagram](img/arch_diagram.png?raw=true "Arch Diagram")
